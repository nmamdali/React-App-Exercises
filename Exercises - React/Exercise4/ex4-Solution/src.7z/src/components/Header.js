import React from 'react'

function Header() {
  return (
    <div className='bg-success text-warning'>
       <h1> Student List</h1>
    </div>
  )
}

export default Header
