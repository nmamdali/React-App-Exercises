const StudentsData = [
        {
            id: 's26j123',
            name: 'Asma Abdullah',
            level: 'Diploma',
            email: 'asma@gmail.com'
        },
        {
            id: 's26j156',
            name: 'Bilal Ahmad',
            level: 'Advanced Diploma',
            email: 'bilal@gmail.com'
        },
        {
            id: 's26j567',
            name: 'Qadir Nasser',
            level: 'Advanced Diploma',
            email:'Qadir@gmail.com'
        },
        {
            id: 's26j878',
            name: 'Ali Munir',
            level: 'Diploma',
            email: 'ali@gmail.com'
        },
        {
            id: 's26j4534',
            name: 'Mustafa Ahamed',
            level: 'Advanced Diploma',
            email: 'mustafa@gmail.com'
        },
        {
            id: 's26j545',
            name: 'Abdubacker Hilal',
            level: 'Diploma',
            email: 'hilal@gmail.com'
        },
        {
            id: 's26j765',
            name: 'Anwar Mohamed',
            level: 'Advanced Diploma',
            email:'anwar@gmail.com'
        },
        {
            id: 's26j4534',
            name: 'Niyaz Ali',
            level: 'Diploma',
            email: 'niyaz@gmail.com'
        },
        
    ];
export default StudentsData;