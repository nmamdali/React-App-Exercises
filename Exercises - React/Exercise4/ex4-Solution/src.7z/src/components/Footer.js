import React from 'react'

function Footer() {
  return (
    <div className='bg-info text-warning'>
       <h5>Prepared by Anas </h5>
    </div>
  )
}

export default Footer
