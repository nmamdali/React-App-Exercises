const BooksData = [
        {
            id: 'e1',
            title: 'I Love You to the Moon and Back',
            author: 'Amelia Hepworth',
            pic: 'https://images-na.ssl-images-amazon.com/images/I/8144Vic9C5L._AC_UL210_SR195,210_.jpg'
        },
        {
            id: 'e2',
            title: 'Ugly Love: A Novel ',
            author: 'Colleen Hoover',
            pic: 'https://m.media-amazon.com/images/I/41mBCtaJ1XL._SY291_BO1,204,203,200_QL40_FMwebp_.jpg'
        },
        {
            id: 'e3',
            title: 'Goodnight Moon',
            author: 'Margaret Wise Brown',
            pic:'https://m.media-amazon.com/images/I/91WuHblNkEL._AC_UY436_FMwebp_QL65_.jpg'
        },
        {
            id: 'e4',
            title: 'A Thousand Boy Kisses',
            author: 'Tillie Cole',
            pic: 'https://m.media-amazon.com/images/I/51yZQoybCsL._SY346_.jpg'
    },
        {
            id: 'e5',
            title: 'Pete the Cat: Snow Daze',
            author: 'James Dean',
            pic: 'https://m.media-amazon.com/images/P/0062404261.01._SCLZZZZZZZ_SX500_.jpg'
        },
        {
            id: 'e6',
            title: 'Life Skills for Kids',
            author: 'Karrn Harris',
            pic: 'https://m.media-amazon.com/images/I/71TPAH06G5L.jpg'
        },
        {
            id: 'e7',
            title: 'Knight Owl',
            author: 'Christopher Denise',
            pic:'https://m.media-amazon.com/images/I/B1G348UJ1rL.jpg'
        },
        {
            id: 'e8',
            title: 'Never Stop Dreaming',
            author: 'Ellen Miles',
            pic: 'https://m.media-amazon.com/images/I/71GrqBmQK2L.jpg'
        },
        
    ];
export default BooksData;