import React from 'react'

function Header() {
  return (
    <div className='bg-warning text-info'>
      <h2>Al Noor Book Store</h2>
    </div>
  )
}

export default Header
