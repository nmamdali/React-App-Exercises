import React from 'react'

function Welcome(props) {
  return (
      <div>
          <h1>Welcome to React{props.n}</h1>
      
    </div>
  )
}

export default Welcome
