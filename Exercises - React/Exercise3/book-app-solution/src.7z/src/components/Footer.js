import React from 'react'

function Footer() {
  return (
    <div className='bg-warning text-success'>
      <h5>Developed by AkashSoft Solution</h5> 
    </div>
  )
}

export default Footer
